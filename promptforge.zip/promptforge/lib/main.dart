import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Free Gemini model. Change here if Google renames it.
const String kModel = 'gemini-2.5-flash';

void main() => runApp(const PromptForgeApp());

class PromptForgeApp extends StatelessWidget {
  const PromptForgeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'PromptForge 3D',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF07070F),
          colorScheme: const ColorScheme.dark(primary: Color(0xFF7C5CFF)),
        ),
        home: const HomePage(),
      );
}

// ---------------- Gemini service ----------------
class Gemini {
  static Future<String> ask(String key, String prompt, {bool json = false}) async {
    final uri = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/$kModel:generateContent?key=$key');
    final res = await http
        .post(uri,
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'contents': [
                {
                  'parts': [
                    {'text': prompt}
                  ]
                }
              ],
              'generationConfig': {
                'temperature': 0.7,
                if (json) 'responseMimeType': 'application/json',
              }
            }))
        .timeout(const Duration(seconds: 120));
    if (res.statusCode != 200) {
      throw Exception('API error ${res.statusCode}. Check your API key / internet.');
    }
    final data = jsonDecode(res.body);
    final parts = data['candidates'][0]['content']['parts'] as List;
    return parts.map((p) => (p['text'] ?? '').toString()).join();
  }
}

// ---------------- Data ----------------
class Q {
  final String text;
  final List<String> options;
  String? selected;
  final TextEditingController custom = TextEditingController();
  Q(this.text, this.options);
  String get answer =>
      custom.text.trim().isNotEmpty ? custom.text.trim() : (selected ?? 'Your best recommendation');
}

// ---------------- Home ----------------
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int stage = 0; // 0 idea, 1 questions, 2 result
  String type = 'App';
  final idea = TextEditingController();
  String apiKey = '';
  bool loading = false;
  String? error;
  List<Q> questions = [];
  String result = '';

  @override
  void initState() {
    super.initState();
    _loadKey();
  }

  Future<void> _loadKey() async {
    final p = await SharedPreferences.getInstance();
    apiKey = p.getString('gemini_key') ?? '';
    if (apiKey.isEmpty && mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _keyDialog());
    }
    setState(() {});
  }

  Future<void> _keyDialog() async {
    final c = TextEditingController(text: apiKey);
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF14142A),
        title: const Text('Gemini API Key (Free)'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text(
              'Get a free key from aistudio.google.com/apikey and paste it here. It stays only on your phone.',
              style: TextStyle(fontSize: 13, color: Colors.white70)),
          const SizedBox(height: 12),
          TextField(
            controller: c,
            decoration: const InputDecoration(hintText: 'AIza...', border: OutlineInputBorder()),
          ),
        ]),
        actions: [
          TextButton(
              onPressed: () async {
                final p = await SharedPreferences.getInstance();
                await p.setString('gemini_key', c.text.trim());
                apiKey = c.text.trim();
                if (ctx.mounted) Navigator.pop(ctx);
                setState(() {});
              },
              child: const Text('Save')),
        ],
      ),
    );
  }

  String _clean(String s) =>
      s.replaceAll('```json', '').replaceAll('```', '').trim();

  Future<void> _getQuestions() async {
    if (idea.text.trim().isEmpty) {
      setState(() => error = 'Please write your idea first.');
      return;
    }
    if (apiKey.isEmpty) {
      _keyDialog();
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final prompt = '''You are a senior product manager and software architect.
The user wants to build a ${type.toLowerCase()}: "${idea.text.trim()}".
Generate exactly 8 confirmation questions needed to write a complete professional build prompt.
Must cover: backend/database, authentication, tech stack/platform, UI style and 3D level, key features, monetization, languages, deployment.
Each question has 3 to 5 short answer options.
Write in the same language style as the user's idea.
Reply ONLY with a JSON array: [{"question":"...","options":["...","..."]}]''';
      final out = await Gemini.ask(apiKey, prompt, json: true);
      final list = jsonDecode(_clean(out)) as List;
      questions = list
          .map((e) => Q(e['question'].toString(),
              (e['options'] as List).map((o) => o.toString()).toList()))
          .toList();
      stage = 1;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
    }
    setState(() => loading = false);
  }

  Future<void> _generate() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final qa = questions.map((q) => 'Q: ${q.text}\nA: ${q.answer}').join('\n\n');
      final prompt = '''Write a COMPLETE, extremely detailed, professional, premium build prompt in English.
It will be pasted into an AI coding assistant to build this ${type.toLowerCase()} fully.
Idea: ${idea.text.trim()}

Confirmed requirements:
$qa

Include these sections with full detail:
1. Project overview and goals
2. Target users
3. Tech stack (exact frameworks, packages)
4. Backend and database (schema, tables/collections, REST API endpoints)
5. Authentication and security
6. Complete feature list
7. Every screen/page described in detail (layout, components, states)
8. Premium 3D UI/UX design system: color palette, typography, depth, layered shadows, glassmorphism, perspective transforms, 3D buttons/cards, animations, micro-interactions, dark/light mode
9. Folder structure
10. Performance, error handling, edge cases
11. Testing
12. Build and deployment steps
13. Step-by-step implementation order
14. Acceptance criteria
Output only the final prompt text.''';
      result = await Gemini.ask(apiKey, prompt);
      stage = 2;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
    }
    setState(() => loading = false);
  }

  void _reset() {
    setState(() {
      stage = 0;
      idea.clear();
      questions = [];
      result = '';
      error = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        const _Glow(top: -80, left: -60, color: Color(0xFF7C5CFF)),
        const _Glow(bottom: -100, right: -80, color: Color(0xFF00D4FF)),
        SafeArea(
          child: Column(children: [
            _header(),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 350),
                child: loading
                    ? const _Loading()
                    : ListView(
                        key: ValueKey(stage),
                        padding: const EdgeInsets.fromLTRB(18, 8, 18, 32),
                        children: [
                          if (error != null) _errorBox(),
                          if (stage == 0) ..._ideaStage(),
                          if (stage == 1) ..._questionStage(),
                          if (stage == 2) ..._resultStage(),
                        ],
                      ),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 8, 4),
        child: Row(children: [
          const Icon(Icons.auto_awesome, color: Color(0xFF9D86FF)),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('PromptForge 3D',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: .5)),
          ),
          IconButton(onPressed: _keyDialog, icon: const Icon(Icons.key_rounded)),
        ]),
      );

  Widget _errorBox() => Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: const Color(0x33FF4D6D),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0x66FF4D6D))),
        child: Text(error!, style: const TextStyle(color: Colors.white)),
      );

  List<Widget> _ideaStage() => [
        Tilt3D(
          child: Glass(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Kya banana hai?',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text(
                  'Apna app ya website ka idea likho. AI pehle sab confirm karega, phir complete professional prompt dega.',
                  style: TextStyle(color: Colors.white70, height: 1.4)),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        Row(children: [
          _typeChip('App', Icons.phone_android),
          const SizedBox(width: 12),
          _typeChip('Website', Icons.language),
        ]),
        const SizedBox(height: 18),
        Glass(
          child: TextField(
            controller: idea,
            maxLines: 6,
            style: const TextStyle(fontSize: 16),
            decoration: const InputDecoration(
                hintText: 'Example: Food delivery app with live tracking...',
                border: InputBorder.none),
          ),
        ),
        const SizedBox(height: 24),
        Btn3D(
            label: 'Next: Confirm Details',
            icon: Icons.arrow_forward_rounded,
            onTap: _getQuestions),
      ];

  Widget _typeChip(String t, IconData i) {
    final on = type == t;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => type = t),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: on
                ? const LinearGradient(colors: [Color(0xFF7C5CFF), Color(0xFF4F8BFF)])
                : null,
            color: on ? null : const Color(0x14FFFFFF),
            border: Border.all(color: Colors.white12),
            boxShadow: on
                ? const [
                    BoxShadow(color: Color(0xFF3B2AA8), offset: Offset(0, 5)),
                    BoxShadow(color: Color(0x667C5CFF), blurRadius: 20, offset: Offset(0, 10)),
                  ]
                : null,
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(i, size: 20),
            const SizedBox(width: 8),
            Text(t, style: const TextStyle(fontWeight: FontWeight.w700)),
          ]),
        ),
      ),
    );
  }

  List<Widget> _questionStage() => [
        const Text('Confirm karo',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        const Text('Option chuno ya apna answer likho.',
            style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 16),
        for (int i = 0; i < questions.length; i++) ...[
          Glass(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${i + 1}. ${questions[i].text}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, height: 1.3)),
              const SizedBox(height: 12),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final o in questions[i].options)
                  ChoiceChip(
                    label: Text(o),
                    selected: questions[i].selected == o,
                    onSelected: (_) => setState(() {
                      questions[i].selected = o;
                      questions[i].custom.clear();
                    }),
                  ),
              ]),
              const SizedBox(height: 10),
              TextField(
                controller: questions[i].custom,
                onChanged: (_) => setState(() => questions[i].selected = null),
                decoration: const InputDecoration(
                    hintText: 'Ya apna answer likho...',
                    isDense: true,
                    border: UnderlineInputBorder()),
              ),
            ]),
          ),
          const SizedBox(height: 14),
        ],
        const SizedBox(height: 10),
        Btn3D(
            label: 'Generate Complete Prompt',
            icon: Icons.bolt_rounded,
            onTap: _generate),
        const SizedBox(height: 6),
        TextButton(onPressed: _reset, child: const Text('Start over')),
      ];

  List<Widget> _resultStage() => [
        const Text('Tumhara Prompt Ready',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        const SizedBox(height: 14),
        Glass(child: SelectableText(result, style: const TextStyle(height: 1.5, fontSize: 14.5))),
        const SizedBox(height: 20),
        Btn3D(
          label: 'Copy Prompt',
          icon: Icons.copy_rounded,
          onTap: () {
            Clipboard.setData(ClipboardData(text: result));
            ScaffoldMessenger.of(context)
                .showSnackBar(const SnackBar(content: Text('Copied!')));
          },
        ),
        const SizedBox(height: 10),
        Btn3D(
          label: 'New Idea',
          icon: Icons.add_rounded,
          colors: const [Color(0xFF00C2A8), Color(0xFF00A3D9)],
          onTap: _reset,
        ),
      ];
}

// ---------------- UI components ----------------
class _Glow extends StatelessWidget {
  final double? top, bottom, left, right;
  final Color color;
  const _Glow({this.top, this.bottom, this.left, this.right, required this.color});
  @override
  Widget build(BuildContext context) => Positioned(
        top: top,
        bottom: bottom,
        left: left,
        right: right,
        child: Container(
          width: 300,
          height: 300,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [color.withOpacity(.35), Colors.transparent]),
          ),
        ),
      );
}

class Glass extends StatelessWidget {
  final Widget child;
  const Glass({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0x1FFFFFFF), Color(0x08FFFFFF)],
          ),
          border: Border.all(color: Colors.white.withOpacity(.12)),
          boxShadow: const [
            BoxShadow(color: Colors.black54, blurRadius: 30, offset: Offset(0, 16)),
            BoxShadow(color: Color(0x227C5CFF), blurRadius: 40, offset: Offset(0, 4)),
          ],
        ),
        child: child,
      );
}

class Tilt3D extends StatefulWidget {
  final Widget child;
  const Tilt3D({super.key, required this.child});
  @override
  State<Tilt3D> createState() => _Tilt3DState();
}

class _Tilt3DState extends State<Tilt3D> {
  double rx = 0, ry = 0;
  @override
  Widget build(BuildContext context) => GestureDetector(
        onPanUpdate: (d) => setState(() {
          ry = (ry + d.delta.dx * 0.004).clamp(-0.25, 0.25);
          rx = (rx - d.delta.dy * 0.004).clamp(-0.25, 0.25);
        }),
        onPanEnd: (_) => setState(() {
          rx = 0;
          ry = 0;
        }),
        child: TweenAnimationBuilder<Offset>(
          tween: Tween(begin: Offset.zero, end: Offset(rx, ry)),
          duration: const Duration(milliseconds: 180),
          builder: (c, o, child) => Transform(
            alignment: Alignment.center,
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.0015)
              ..rotateX(o.dx)
              ..rotateY(o.dy),
            child: child,
          ),
          child: widget.child,
        ),
      );
}

class Btn3D extends StatefulWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onTap;
  final List<Color> colors;
  const Btn3D({
    super.key,
    required this.label,
    required this.icon,
    this.onTap,
    this.colors = const [Color(0xFF7C5CFF), Color(0xFF4F8BFF)],
  });
  @override
  State<Btn3D> createState() => _Btn3DState();
}

class _Btn3DState extends State<Btn3D> {
  bool down = false;
  @override
  Widget build(BuildContext context) {
    final dark = HSLColor.fromColor(widget.colors.first)
        .withLightness(.22)
        .toColor();
    return GestureDetector(
      onTapDown: (_) => setState(() => down = true),
      onTapCancel: () => setState(() => down = false),
      onTapUp: (_) {
        setState(() => down = false);
        widget.onTap?.call();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        margin: EdgeInsets.only(top: down ? 6 : 0, bottom: down ? 0 : 6),
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(colors: widget.colors),
          boxShadow: [
            BoxShadow(color: dark, offset: Offset(0, down ? 0 : 6)),
            BoxShadow(
                color: widget.colors.first.withOpacity(.45),
                blurRadius: 24,
                offset: const Offset(0, 12)),
          ],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(widget.icon, size: 22),
          const SizedBox(width: 10),
          Text(widget.label,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class _Loading extends StatelessWidget {
  const _Loading();
  @override
  Widget build(BuildContext context) => const Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(
              width: 54,
              height: 54,
              child: CircularProgressIndicator(strokeWidth: 5, color: Color(0xFF9D86FF))),
          SizedBox(height: 18),
          Text('AI kaam kar raha hai...', style: TextStyle(color: Colors.white70)),
        ]),
      );
}
